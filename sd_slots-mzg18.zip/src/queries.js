import { HttpError } from 'wasp/server'

export const getUserSpins = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  const user = await context.entities.User.findUnique({ where: { id: args.userId } })
  if (!user) { throw new HttpError(400, 'User does not exist') }
  return context.entities.Spin.findMany({ where: { userId: args.userId } })
}

export const getUser = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const user = await context.entities.User.findUnique({
    where: { id },
    select: {
      id: true,
      username: true,
      balance: true,
      spins: true
    }
  });

  if (!user) throw new HttpError(400, 'User with id ' + id + ' does not exist');

  return user;
}