import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useAction, getUser, getUserSpins, loadFunds, spin } from 'wasp/client/operations';

const DashboardPage = () => {
  const { data: user, isLoading: userLoading, error: userError } = useQuery(getUser);
  const { data: spins, isLoading: spinsLoading, error: spinsError } = useQuery(getUserSpins, { userId: user.id });
  const loadFundsFn = useAction(loadFunds);
  const spinFn = useAction(spin);
  const [betAmount, setBetAmount] = useState(0);

  if (userLoading || spinsLoading) return 'Loading...';
  if (userError || spinsError) return 'Error: ' + (userError || spinsError);

  const handleLoadFunds = (amount) => {
    loadFundsFn({ amount });
  };

  const handleSpin = () => {
    spinFn({ bet: betAmount });
  };

  return (
    <div className='p-4 text-white bg-black'>
      <div>Balance: {user.balance}</div>
      <button
        onClick={() => handleLoadFunds(100)}
        className='bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mt-2'
      >
        Load $100
      </button>
      <div>
        {spins.map((spin) => (
          <div
            key={spin.id}
            className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'
          >
            <div>{spin.result}</div>
            <div>Bet: {spin.bet}</div>
          </div>
        ))}
      </div>
      <div className='mt-4'>
        <input
          type='number'
          placeholder='Bet amount'
          className='px-1 py-2 border rounded text-lg'
          value={betAmount}
          onChange={(e) => setBetAmount(parseFloat(e.target.value))}
        />
        <button
          onClick={handleSpin}
          className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded ml-2'
        >
          Spin
        </button>
      </div>
    </div>
  );
}

export default DashboardPage;