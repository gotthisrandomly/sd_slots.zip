import React from 'react';
import { useQuery, useAction, getUser, getUserSpins, loadFunds } from 'wasp/client/operations';
import { Link } from 'react-router-dom';

const Admin = () => {
  const { data: user, isLoading: userLoading, error: userError } = useQuery(getUser);
  const { data: spins, isLoading: spinsLoading, error: spinsError } = useQuery(getUserSpins);
  const loadFundsFn = useAction(loadFunds);

  if (userLoading || spinsLoading) return 'Loading...';
  if (userError || spinsError) return 'Error: ' + (userError || spinsError);

  return (
    <div className='p-4'>
      <div className='text-xl font-bold mb-4'>Admin Panel</div>
      <div className='grid grid-cols-3 gap-4'>
        <div className='bg-gray-100 p-4 rounded-lg'>
          <div className='font-bold'>User Information:</div>
          <div>Username: {user.username}</div>
          <div>Balance: ${user.balance}</div>
        </div>
        <div className='bg-gray-100 p-4 rounded-lg'>
          <div className='font-bold'>Spins:</div>
          {spins.map((spin) => (
            <div key={spin.id} className='flex justify-between items-center border-b py-2'>
              <div>{spin.result}</div>
              <div>Bet: ${spin.bet}</div>
            </div>
          ))}
        </div>
        <div className='bg-gray-100 p-4 rounded-lg'>
          <div className='font-bold'>Actions:</div>
          <button
            onClick={() => loadFundsFn({ userId: user.id, amount: 100 })}
            className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-4'
          >
            Load $100
          </button>
          <Link
            to='/dashboard'
            className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4 block'
          >
            Go to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Admin;