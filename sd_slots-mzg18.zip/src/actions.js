import { HttpError } from 'wasp/server'

export const spin = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const user = await context.entities.User.findUnique({
    where: { id: context.user.id }
  });

  if (user.balance < args.bet) { throw new HttpError(400, 'Insufficient balance') };

  const result = Math.random() < 0.99 ? 'win' : 'lose';
  const newBalance = user.balance + (result === 'win' ? args.bet : -args.bet);

  const updatedUser = await context.entities.User.update({
    where: { id: context.user.id },
    data: { balance: newBalance }
  });

  const newSpin = await context.entities.Spin.create({
    data: {
      result: result,
      bet: args.bet,
      userId: context.user.id
    }
  });

  return { user: updatedUser, spin: newSpin };
}

export const loadFunds = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const updatedUser = await context.entities.User.update({
    where: { id: context.user.id },
    data: { balance: { increment: args.amount } }
  });

  return updatedUser;
}